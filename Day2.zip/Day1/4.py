firstname=input("Enter your first name: ")
lastname=input("Enter your last name: ")
wholename=firstname + "." + lastname
print(wholename)
