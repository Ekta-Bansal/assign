x=input("Enter a number: ")
a=[i for i in input("list:").split()]
flag=1
for i in a:
	if(i == x):
		print("TRUE")
		break
	else:
		flag=0
if(flag!=1):
        print("False")
