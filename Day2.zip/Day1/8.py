a=[i for i in input("list:").split()]
b=[j for j in input("list2:").split()]
flag=0
for i in a:
	for j in b:
		if(i == j):
			flag=1
			print("TRUE")
			break
		else:
			flag=0
if(flag==0):
        print("False")
