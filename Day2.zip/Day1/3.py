a=121
b=int(input("Enter number: "))
while b != a:
	b=int(input("Enter number: "))

print(a,"Correct!")
