a=[int(i) for i in input("list:").split()]
str=""
for i in a:
	while i>0 :
		str=str+"*"
		i-=1
	print(str)
	str=""
