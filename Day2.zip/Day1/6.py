a=[int(i) for i in input("list:").split()]
add=0
mul=1
for x in a:
	add+=x
	mul*=x
print("Sum of number is: ",add)
print("Multiplication of number is: ",mul)

