import string
ignored= string.punctuation + " "
def palindrome(str):
	str1=""
	for i in str:
		if i not in ignored: str1 +=i.lower()
	return str1 == str1[::-1]
print(palindrome(input("Enter a string:")))
