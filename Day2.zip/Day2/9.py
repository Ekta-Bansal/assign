def char_freq(str1):
	dict={}
	for n in str1:
		key=dict.keys()
		if n in key:
			dict[n]+=1
		else:
			dict[n]=1
	return dict
print(char_freq(input("Enter a string: ")))