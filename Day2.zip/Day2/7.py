def is_pangram(string):
	al="abcdefghijklmnopqrstuvwxyz"
	for i in al:
		if i not in string:
			return False
	return True
print(is_pangram(input("Enter a string: ")))
