#def find_longest_word(a):
#	return max(a,key=lambda s:(len(s),s))
#print(find_longest_word([i for i in input("list:").split()]))

def find_longest_word(a):
	word_len= []
	for n in a:
		word_len.append((len(n),n))
	word_len.sort()
	return word_len[-1][1]
print(find_longest_word([i for i in input("list:").split()]))


