a=[i for i in input("list:").split()]
s=0
b=list()
for i in a:
	b.insert(s,len(i))
	s+=1
print(b)
