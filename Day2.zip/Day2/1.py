def generate_n_chars(a,b):
	c=""
	while a>0:
		c=c+b
		a-=1
	return c
print(generate_n_chars(int(input("Enter number: ")),input("Enter string: ")))
