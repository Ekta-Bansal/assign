engtoswe={"merry":"god", "christmas":"jul", "and":"och", "happy":"gott",
          "new":"nytt", "year":"år"}
def englishtoswedish(word):
	engtoswe={"merry":"god", "christmas":"jul", "and":"och",
                  "happy":"gott", "new":"nytt", "year":"år"}
	if word in engtoswe:
		return engtoswe.get(word)
	else:
		return word
def translate(string):
	new = ""
	for i in string:
		new = new + englishtoswedish(i) +" "
	return new
print(translate([i for i in input("list:").split()]))
