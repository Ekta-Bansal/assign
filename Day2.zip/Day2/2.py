def max_in_list(a):
	b=a[0]
	for i in a:
		if b<i:
			b=i
	return b
print(max_in_list([int(i) for i in input("list:").split()]))
