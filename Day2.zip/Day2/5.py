def long_words(n,str):
	word_len=[]
	for x in str:
		if len(x) > n:
			word_len.append(x)
	return word_len
print(long_words(int(input("Enter min word length: ")),[i for i in input("list:").split()]))

